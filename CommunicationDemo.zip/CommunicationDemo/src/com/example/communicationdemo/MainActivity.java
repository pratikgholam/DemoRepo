package com.example.communicationdemo;

import android.os.Bundle;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    public void sendSMS(View view){
    	SmsManager smsManager= SmsManager.getDefault();
    
    	Intent intent_sent = new Intent(SMS_SENT_ACTION);
    	PendingIntent pIntent_sent = PendingIntent.getBroadcast(this, 0, intent_sent, 0);
    	
    	Intent intent_delivery = new Intent(SMS_DELIVERED_ACTION);
    	PendingIntent pIntent_delivery = PendingIntent.getBroadcast(getApplicationContext(), 0, intent_delivery, PendingIntent.FLAG_UPDATE_CURRENT);
    	
    	registerReceiver(new BroadcastReceiver() {
			
			@Override
			public void onReceive(Context context, Intent intent) {
				switch (getResultCode()) {
				case Activity.RESULT_OK:
					System.out.println("Ok....");
					break;
				case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
					System.out.println("Generic Failure");
					break;
				case SmsManager.RESULT_ERROR_RADIO_OFF :
					System.out.println("Radio Off");
					break;
				case SmsManager.RESULT_ERROR_NULL_PDU:
					System.out.println("Null PDU");
					break;
				case SmsManager.RESULT_ERROR_NO_SERVICE:
					System.out.println("No Service");
				
				default:
					System.out.println("ERROR !!!!");
					break;
				}
				
			}
		}, new IntentFilter(SMS_SENT_ACTION));
    	
    	registerReceiver(new BroadcastReceiver() {
			
			@Override
			public void onReceive(Context context, Intent intent) {
				// TODO Auto-generated method stub
				System.out.println("Message Delivered...");
				switch (getResultCode()) {
				case Activity.RESULT_OK:
					System.out.println("Ok....");
					break;
					default:
						System.out.println("Delivery Failed !!!!");
				}
			}
		}, new IntentFilter(SMS_DELIVERED_ACTION));
    	
    	smsManager.sendTextMessage("5556", null, "Hello from Android",pIntent_sent,pIntent_delivery);
    System.out.println("Message Sent");
    
    }
    String SMS_SENT_ACTION = "SMS_SENT";
    String SMS_DELIVERED_ACTION="SMS_DELIVERED";
    
    public void receiveCall(View view){
    	Intent i = new Intent(this,TelephonyActivity.class);
    	startActivity(i);
    }
    
}
