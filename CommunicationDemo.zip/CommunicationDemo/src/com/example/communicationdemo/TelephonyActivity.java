package com.example.communicationdemo;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.Menu;

public class TelephonyActivity extends Activity {
	
	TelephonyManager telephonyManager;
	PhoneStateListener phoneStateListener;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_telephony);
		
		// Get the telephony manager

        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        // Create a new PhoneStateListener
        phoneStateListener = new PhoneStateListener() {
          @Override
          public void onCallStateChanged(int state, String incomingNumber) {

            String stateString = "N/A";

            switch (state) {

            case TelephonyManager.CALL_STATE_IDLE:

              stateString = "Idle";

              break;

            case TelephonyManager.CALL_STATE_OFFHOOK:

              stateString = "Off Hook";

              break;

            case TelephonyManager.CALL_STATE_RINGING:

              stateString = "Ringing";

              break;
            }

            System.out.println(String.format("\nCallState: %s", stateString));

          }

        };


        // Register the listener wit the telephony manager

        telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);

		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.telephony, menu);
		return true;
	}

}
